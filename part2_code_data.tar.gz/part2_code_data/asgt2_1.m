%asgt2-1
% rows are documents, columns are words.
% want to add 1 to each row

% 2.1.a
% This script adds a bias vector to the data given in 'text_data.mat'. I
% made a copy of text_data.mat so that I don't add another bias vector
% every time I run the script.
load('text_data (copy)');
xtest = horzcat(x_test,ones(1625,1));
x_test=xtest;
xtrain = horzcat(x_train,ones(6499,1));
x_train=xtrain;
save('text_data','x_test','x_train','y_test','y_train');

%{
2.1.b
Accuracy on the training set: 0.618 +/- 0.006
Mean log probability on the training set: -0.440 +/- 0.429
Accuracy on the test set: 0.628 +/- 0.012
Mean log probability on the test set: -0.292 +/- 0.106
%}
% Minimize the negative log likelihood.

% initialize all weights to 1.
weights=ones(101,1);
% create an anonymous function
anon=@(ww,xx,yy) neg_lr_loglike(ww,xx,yy);
% minimize the weights
[X, fx, i] = minimize(weights,anon,-1000,x_train,y_train);

% Evaluate P(y|x,w) for all x in x_train
sigs = 1./(1 + exp(-y_train.*(x_train*X)));
% the following three lines modified from minimize.m, by Carl Edward Rasmussen, 2010-01-03
sigmas=round(sigs);
sigmas = (sigmas==1)*2 - 1;
accuracy=mean(y_train==sigmas);
variance=var(y_train==sigmas);
% The following two lines adapted from tutorial 5 solutions.
stderr = sqrt(variance/size(y_train,1));
horzcat(sigs,sigmas,y_train)
fprintf('Accuracy on the training set: %1.3f +/- %1.3f\n', accuracy, stderr);

% find mean log probability that predictions assign to training labels
meanlogprob = mean(log(sigs));
varlogprob = var(log(sigs));
fprintf('Mean log probability on the training set: %1.3f +/- %1.3f\n', meanlogprob, varlogprob);

% Evaluate P(y|x,w) for all x in x_test
sigs = 1./(1 + exp(-y_test.*(x_test*X)));
% calculate accuracy on test set
sigmas=round(sigs);
sigmas = (sigmas==1)*2 - 1;
accuracy=mean(y_test==sigmas);
variance=var(y_test==sigmas);
% The following two lines adapted from tutorial 5 solutions.
stderr = sqrt(variance/size(y_test,1));
fprintf('Accuracy on the test set: %1.3f +/- %1.3f\n', accuracy, stderr);

% find mean log probability that predictions assign to test labels
meanlogprob = mean(log(sigs));
varlogprob = var(log(sigs));
fprintf('Mean log probability on the test set: %1.3f +/- %1.3f\n', meanlogprob, varlogprob);

% Is the mean log probability better than a baseline that predicts 
% P(y|x)=0.5 for every test case?
%{
We know that a baseline that predicts P(y|x)=0.5 makes no assumptions
about the data, so it will have error of 0.5 for every prediction.  Mean
probability, however, will predict closer to the label that it predicts
as more common.  So long as the label it predicts as more common IS more
common, a baseline that uses mean probability will be better.
%}

meanprob = exp(meanlogprob);
meanerror = mean(abs(ones(size(y_test,1),1).*meanprob - ((y_test+1)./2)));

% meanerror = 0.4646

%{
A little snippet of code confirms our suspicion.  The mean error between
the mean probability and the labels is less than 0.5, indicating that the
mean probability is better.
%}

%{
2.1.c
Limited Training Data: Fit your model using only the first 100 training
cases.
Accuracy on the test set: 0.546 +/- 0.012
Mean log probability on the test set: -Inf +/- NaN

Because a small training set was used, many of the weights in the weight
vector quicky minimize to either 0 or 1, indicating that in this small 
training set, all feature vectors with a certain value for a certain
feature had the same label.  In our concrete text classification example,
this would indicate that for instance that only sports-labelled documents 
contained the word "pass."
When this weight vector is used to classify a document, the linear
regressor returns values of zero or one.  This is an artifact of weight
vectors that over-generalize the likelihood of seeing a given feature in a
document of a given label, but the effect is to make the regressor entirely
certain of a document's label.  If the regressor returns a probability of 0
for any of the documents in the test set, then the mean log probability
becomes -Inf +/- NaN.
%}

% guess initially that all instances are classified as 1.
weights=ones(101,1);

% minimize the weights, using only 100 training points
[X2, fx, i] = minimize(weights,anon,-1000,x_train(1:100,:),y_train(1:100,:));

% Evaluate P(y|x,w) for all x in x_test
sigs = 1./(1 + exp(-y_test.*(x_test*X2)));
% calculate accuracy on test set
sigmas=round(sigs);
sigmas = (sigmas==1)*2 - 1;
accuracy=mean(y_test==sigmas);
variance=var(y_test==sigmas);
% The following two lines adapted from tutorial 5 solutions.
stderr = sqrt(variance/size(y_test,1));
fprintf('Accuracy on the test set: %1.3f +/- %1.3f\n', accuracy, stderr);

% find mean log probability that predictions assign to test labels
meanlogprob = mean(log(sigs));
varlogprob = var(log(sigs));
fprintf('Mean log probability on the test set: %1.3f +/- %1.3f\n', meanlogprob, varlogprob);
