function [Lp, dLp_deps, dLp_dw] = eps_lr_loglike2 (ww,epsilon,xx,yy)
%EPS_LR_LOGLIKE2 log-likelihood and gradients of logistic regression
%
%     [Lp, dLp_deps dLp_dw] = lr_loglike(ww, xx, yy);
%     Exactly the same as the first, but with the second and third return
%     values switched for compatibility with checkgrad.
%
% Inputs:
%          ww Dx1 logistic regression weights
%     epsilon 1x1 probability that label was assigned uniform randomly
%          xx NxD training data, N feature vectors of length D
%          yy Nx1 labels in {+1,-1} or {1,0}
%
% Outputs:
%          Lp 1x1 log-probability of data, the log-likelihood of ww
%      dLp_dw Dx1 gradients: partial derivatives of Lp wrt ww
%    dLp_deps 1x1 gradient: partial derivative of Lp wrt epsilon

% Owen Chapman, November 2015, adapted from
% Iain Murray, October 2014, August 2015

% Ensure labels are in {+1,-1}:
yy = (yy==1)*2 - 1;

sigmas = 1./(1 + exp(-yy.*(xx*ww))); % Nx1
probs = sigmas.*(1-epsilon)+epsilon/2;
Lp = sum(log(probs));

if nargout > 2
    numerator = (1-epsilon)*sigmas.*(1-sigmas);
    denominator = (1-epsilon)*sigmas+(epsilon/2);
    dLp_dw = (((numerator./denominator).*yy)' * xx)';
end

if nargout > 1
    numerator = sigmas.*(-1)+.5;
    denominator = (1-epsilon)*sigmas+(epsilon/2);
    dLp_deps = sum(numerator./denominator);

end
end
    
