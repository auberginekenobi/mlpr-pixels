function [nLp, ndLp_dw] = neg_lr_loglike(ww,xx,yy)
% inverts the outputs given by lr_loglike. Couldn't figure out how to do it
% in an anonymous function.
[ll,dll]=lr_loglike(ww,xx,yy);
[nLp]=times([ll],[(-1)]);
[ndLp_dw]=times([dll],[ones(101,1)*(-1)]);
end