%{
2.2.a
Made a function that determines the log likelihood wrt w and epsilon called
eps_lr_loglike.m (ww,epsilon,xx,yy).

My test case used the method provided in checkgrad.m with arbitrarily
initialized values for the weights and the noise parameter epsilon of 0.5 
(for all 101 weights) and 0.1 respectively.  The small peturbation h used 
was 1e-3.  
Checkgrad.m prints the values of the calculated derivatives and the
approximations side-by-side, and returns the norm of the difference divided
by the norm of the sum as a measure of accuracy.  Qualitatively, the
calculated derivative did not differ from the approximations for any of the
weights by more than the 0.1 sensitivity printed by checkgrad.m.  The
calculated derivative and the approximation differed by 0.1.  It reports an
accuracy of 3.8e-8 for the weights and 6.3e-6 for the noise, indicating
that the calculated gradients are correct.

%}

load('text_data');
% now using checkgrad to check my gradient eps_lr_loglike function.
% initialize all weights to 1, epsilon to .1
weights=ones(101,1)*.5;
epsilon=[.1];
% create an anonymous function
anonweights=@(ww,epsilon,xx,yy) eps_lr_loglike(ww,epsilon,xx,yy);
anonepsilon=@(epsilon,ww,xx,yy) eps_lr_loglike2(ww,epsilon,xx,yy); % note that eps_lr_loglike2 is the same as the original, but with the 2nd and 3rd arguments switched.
% check gradient
[Lp,dw,deps]= eps_lr_loglike(weights,epsilon,x_train,y_train);
%d = checkgrad(anonweights,weights,1e-3,epsilon,x_train,y_train)
%e = checkgrad(anonepsilon,epsilon,1e-3,weights,x_train,y_train)

%{
2.2.b
Fitted noise level: epsilon = 0.212
Accuracy on the test set: 0.591 +/- 0.012
Mean log probability on the test set: -0.415 +/- 5.405

For comparison, the weights without a noise parameter produced an accuracy
of 0.618 +/- 0.006 and a mean log probability of -0.440 +/- 0.429 on the
test set.  The linear regressor therefore performed slightly but
significatnly worse when a noise parameter was included to model real-world
noise.  This may be because the test set was checked more carefully than
the training set, so the weights obtained using the noise parameter are
tuned for a much greater amount of noise than actually was present in the
test set.  However, it is important to note that the two accuracies were
almost the same, and the addition of noise had a minimal influence on
prediction.  This is because noisy labels are added randomly, making it
difficult for a model to gain much information from the tuning of a noise
parameter.
%}

% initialize all weights to 1.
weights=ones(101,1); %101x1
a=.7;
% create an anonymous function, combining weights and 'a' into a single
% vector with 'a' concatenated at the end of the weight vector.
anon=@(ww,xx,yy) nll_constrained(ww,xx,yy);
% minimize the weights
combinedvector=vertcat(weights,a);
[X, fx, i] = minimize(combinedvector,anon,-1000,x_train,y_train);
epsilon = 1/(1 + exp(-X(end,:)));
fprintf('epsilon: %1.3f\n', epsilon);
% epsilon = 0.212

% Predict using new weights
X = X(1:end-1,:);
% The following copied from 2.1
% Evaluate P(y|x,w) for all x in x_test
sigs = 1./(1 + exp(-y_test.*(x_test*X)));
% calculate accuracy on test set
sigmas=round(sigs);
sigmas = (sigmas==1)*2 - 1;
accuracy=mean(y_test==sigmas);
variance=var(y_test==sigmas);
% The following two lines adapted from tutorial 5 solutions.
stderr = sqrt(variance/size(y_test,1));
fprintf('Accuracy on the test set: %1.3f +/- %1.3f\n', accuracy, stderr);

% find mean log probability that predictions assign to test labels
meanlogprob = mean(log(sigs));
varlogprob = var(log(sigs));
fprintf('Mean log probability on the test set: %1.3f +/- %1.3f\n', meanlogprob, varlogprob);
