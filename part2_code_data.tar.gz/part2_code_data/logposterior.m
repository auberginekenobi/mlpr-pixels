function result = logposterior (wvector,xx,yy)

% break wvector into weights, epsilon, lambda
ww=wvector(1:end-2,:);
epsilon=wvector(end-1,:);
lambda=wvector(end,:);

% calculate log likelihood (similar to 2.2, from nll_constrained.m)
Lp=0;
if epsilon > 0  && epsilon < 1
    sigmas = 1./(1 + exp(-yy.*(xx*ww))); % Nx1
    probs = sigmas.*(1-epsilon)+epsilon/2;
    Lp = sum(log(probs));
end

% terrible name, I know...
lwtw = (ww'*ww)*lambda;

% last term
dtll = size(yy,1)/2*log(lambda);

result = Lp - lwtw + dtll;
end