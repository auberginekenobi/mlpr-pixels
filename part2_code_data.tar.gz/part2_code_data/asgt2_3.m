%{
2.3.a
Written on paper. Don't lose it.
%}

%{
2.3.b

%}

load('text_data');
% initialize w, epsilon, and lambda
weights = ones(101,1);
epsilon=1;
lambda=1;

wvector = vertcat(weights,epsilon,lambda);
logposthandle = @(wvector,xx,yy) (logposterior(wvector,xx,yy));

samples = slice_sample(1000,100,logposthandle,wvector,100,true,x_train,y_train)
%didn't work...

%{
2.3.c
Because these samples of the weight vector w are all valid samples from the
posterior, one means of using the samples to make predictions is to use
samples from a local maximum to make predictions; that is, find a mode in
the samples, and use these weights to make predictions on the data.  Seing
as I didn't manage to make my slice sampler work, I can't report back on
how well this method works.
%}

