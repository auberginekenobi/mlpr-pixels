function [nLp, ndLp_dw] = nll_constrained (ww,xx,yy)

% nll_constrained
% 
% Inputs:
%          ww D+2x1 logistic regression weights. The second-to-last is a
%          bias weight, and the last a value for aa.
%          xx NxD training data, N feature vectors of length D
%          yy Nx1 labels in {+1,-1} or {1,0}
%
% Outputs:
%          Lp 1x1 log-probability of data, the log-likelihood of ww
%      dLp_dw Dx1 gradients: partial derivatives of Lp wrt ww
%    dLp_deps 1x1 gradient: partial derivative of Lp wrt epsilon

% split ww into weights and aa
aa = ww(end,:);
ww = ww(1:end-1,:);
%w=ww;
% calculate epsilon from a
e = 1/(1 + exp(-aa));

% Lp, dPl_dw, dLp_deps
[a,b,c] = eps_lr_loglike(ww,e,xx,yy);

% want gradient wrt a, not epsilon.
c = c * e *(1-e);

% outputs
[nLp]=a*(-1);
[ndLp_dw]=vertcat(b,c).*(-1);


end